# -*- coding: utf-8 -*-
"""
Created on Tue Dec 31 03:00:04 2024

@author: hp Omen 15 ek
"""

from tkinter import *
#import ttk
from tkinter.ttk import *
from tkinter import filedialog
import tkinter.messagebox as tkMessageBox 
#import tkFileDialog
#import tkMessageBox

from Viewer2d.MatViewer import MatViewer
from Viewer3d.VisPyViewer import VisPyViewer

from tkinter import *
from tkinter import filedialog, messagebox
from tkinter.ttk import Frame, Button, Label, Radiobutton, Combobox, Style


# Browse button function
def browse_button():
    filename = filedialog.askopenfilename(filetypes=[("PDB files", "*.pdb"), ("All files", "*.*")],
                                          title="Select your PDB file")
    folder_path.set(filename)

    try:
        endname = "..." + filename[-9:]
    except:
        endname = filename

    pathname.set(endname)


class ProteinViewer:
    def __init__(self, master):
        # Add styles
        self.style = Style()
        self.style.configure("TButton", font=("Arial", 12), padding=5)
        self.style.configure("TLabel", font=("Arial", 12))
        self.style.configure("TRadiobutton", font=("Arial", 11))
        self.style.configure("TCombobox", font=("Arial", 11))

        # Create main frame
        frame = Frame(master, padding=20)
        frame.grid(column=0, row=0, sticky=(N, W, E, S))
        frame.columnconfigure(0, weight=1)
        frame.rowconfigure(0, weight=1)

        # File selection
        global folder_path
        global pathname

        folder_path = StringVar()
        pathname = StringVar()
        pathname.set("...")

        # Header title
        self.header = Label(frame, text="Bhatti's Protein Viewer", font=("Helvetica", 16, "bold"), anchor="center")
        self.header.grid(row=0, columnspan=2, pady=(0, 20))

        # File selection section
        self.title1 = Label(frame, text="Select your file:", font=("Helvetica", 12))
        self.title1.grid(row=1, columnspan=2, sticky=W, pady=(0, 5))

        self.browse_button = Button(frame, text="Browse", command=browse_button)
        self.browse_button.grid(row=2, column=0, sticky=W)

        self.path_label = Label(frame, textvariable=pathname, width=30, style="TLabel")
        self.path_label.grid(row=2, column=1, sticky=W)

        # Library choice
        self.title2 = Label(frame, text="Select the library:", font=("Helvetica", 12))
        self.title2.grid(row=3, columnspan=2, sticky=W, pady=(20, 5))

        self.ltype = StringVar()
        self.ltype.set("matplot")

        self.lib1 = Radiobutton(frame, text="MatPlot", variable=self.ltype, value="matplot", style="TRadiobutton")
        self.lib1.grid(row=4, column=0, sticky=W)

        self.lib2 = Radiobutton(frame, text="VisPy", variable=self.ltype, value="vispy", style="TRadiobutton")
        self.lib2.grid(row=4, column=1, sticky=W)

        # Visualization type
        self.title3 = Label(frame, text="Select the visualization type:", font=("Helvetica", 12))
        self.title3.grid(row=5, columnspan=2, sticky=W, pady=(20, 5))

        self.vtype = StringVar()
        choices = ['select', 'CPK', 'Residue type', 'Chains', 'DSSP program']
        self.vtype.set('CPK')

        self.combo = Combobox(frame, textvariable=self.vtype, values=choices, state="readonly")
        self.combo.grid(row=6, columnspan=2, sticky=W)

        # Run button
        self.run_button = Button(frame, text="Run", command=self.vis_options, style="TButton")
        self.run_button.grid(row=7, columnspan=2, pady=(20, 0))

    # Command for the Run button
    def vis_options(self):
        choices_dict = {'CPK': 'cpk', 'Residue type': 'aminoacid', 'Chains': 'backbone', 'DSSP program': 'dssp'}

        if folder_path.get()[-4:] != '.pdb':
            messagebox.showerror("Error", "You have not selected a PDB file")
        else:
            if self.ltype.get() == "matplot":
                #print(f"Running MatPlot with {folder_path.get()} and {choices_dict[self.vtype.get()]}")
                MatViewer(folder_path.get(), choices_dict[self.vtype.get()])
            else:
                #print(f"Running VisPy with {folder_path.get()} and {choices_dict[self.vtype.get()]}")
                VisPyViewer(folder_path.get(), choices_dict[self.vtype.get()], "Viewer3d/CPK-Jmol.png")


# Main Tkinter window
root = Tk()
root.geometry("400x400")
root.title("Protein Viewer")
root.configure(bg="#add8e6")  # Light background

app = ProteinViewer(root)
root.mainloop()
